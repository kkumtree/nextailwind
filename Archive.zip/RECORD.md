# What I typed

## init

```bash
yarn create next-app isitright --eslint --typescript
```

## custom

- yarn add antd @reduxjs/toolkit
- yarn add -D tailwindcss postcss autoprefixer
- .prettierrc.js 생성
- npx install-peerdeps --dev eslint-config-airbnb
- .eslintrc.js 생성
- yarn add --dev --exact prettier
- npx install-peerdeps --dev eslint-config-prettier
